from datetime import date, datetime
from decimal import Decimal
from typing import Literal
from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator


class StudentCreate(BaseModel):
    full_name: str = Field(min_length=2, max_length=120)
    email: str | None = Field(default=None, max_length=160)
    phone: str | None = Field(default=None, max_length=30)
    class_name: str = Field(min_length=1, max_length=80)
    guardian_name: str | None = Field(default=None, max_length=120)


class StudentOut(StudentCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    created_at: datetime


class TeacherCreate(BaseModel):
    full_name: str = Field(min_length=2, max_length=120)
    email: str = Field(min_length=5, max_length=160)
    phone: str | None = Field(default=None, max_length=30)
    subject: str = Field(min_length=1, max_length=100)
    joining_date: date | None = None
    monthly_salary: Decimal = Field(gt=0, max_digits=10, decimal_places=2)


class TeacherOut(TeacherCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    created_at: datetime


class StudentAttendanceCreate(BaseModel):
    student_id: int
    attendance_date: date = Field(default_factory=date.today)
    status: Literal["present", "absent", "late", "excused"]
    notes: str | None = None


class StudentAttendanceOut(StudentAttendanceCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    created_at: datetime


class TeacherCheckIn(BaseModel):
    teacher_id: int
    attendance_date: date = Field(default_factory=date.today)
    status: Literal["present", "late"] = "present"
    check_in: datetime = Field(default_factory=datetime.now)
    notes: str | None = None


class TeacherAttendanceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    teacher_id: int
    attendance_date: date
    status: str
    check_in: datetime | None
    check_out: datetime | None
    notes: str | None
    created_at: datetime


class SalaryCreate(BaseModel):
    teacher_id: int
    salary_month: str = Field(pattern=r"^\d{4}-(0[1-9]|1[0-2])$")
    base_salary: Decimal = Field(gt=0, max_digits=10, decimal_places=2)
    allowances: Decimal = Field(default=Decimal("0.00"), ge=0, max_digits=10, decimal_places=2)
    deductions: Decimal = Field(default=Decimal("0.00"), ge=0, max_digits=10, decimal_places=2)
    notes: str | None = None

    @field_validator("deductions")
    @classmethod
    def deductions_not_above_total(cls, value, info):
        base = info.data.get("base_salary", Decimal("0"))
        allowances = info.data.get("allowances", Decimal("0"))
        if value > base + allowances:
            raise ValueError("Deductions cannot exceed base salary plus allowances")
        return value


class SalaryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    teacher_id: int
    salary_month: str
    base_salary: Decimal
    allowances: Decimal
    deductions: Decimal
    status: str
    paid_at: datetime | None
    notes: str | None
    created_at: datetime


class SalarySummary(BaseModel):
    id: int
    teacher_id: int
    salary_month: str
    base_salary: Decimal
    allowances: Decimal
    deductions: Decimal
    net_salary: Decimal
    status: str
    paid_at: datetime | None
