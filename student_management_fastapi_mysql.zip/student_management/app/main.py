from contextlib import asynccontextmanager
from fastapi import FastAPI
from sqlalchemy.exc import OperationalError
from .database import Base, engine
from . import models  # noqa: F401 - ensures SQLAlchemy knows all models
from .routers import students, teachers, attendance, salaries


@asynccontextmanager
async def lifespan(app: FastAPI):
    # For a starter project only. Use Alembic migrations for production.
    Base.metadata.create_all(bind=engine)
    yield


app = FastAPI(
    title="Student Management System API",
    description="REST API for students, teachers, attendance, check-in/out, and salaries.",
    version="1.0.0",
    lifespan=lifespan,
)

app.include_router(students.router)
app.include_router(teachers.router)
app.include_router(attendance.router)
app.include_router(salaries.router)


@app.get("/", tags=["Health"])
def root():
    return {"message": "Student Management System API is running", "docs": "/docs"}


@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok"}
