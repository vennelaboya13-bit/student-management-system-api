from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Student, StudentAttendance, Teacher, TeacherAttendance
from ..schemas import (StudentAttendanceCreate, StudentAttendanceOut, TeacherCheckIn,
                       TeacherAttendanceOut)

router = APIRouter(prefix="/attendance", tags=["Attendance"])


@router.post("/students/", response_model=StudentAttendanceOut, status_code=status.HTTP_201_CREATED)
def mark_student_attendance(payload: StudentAttendanceCreate, db: Session = Depends(get_db)):
    if not db.get(Student, payload.student_id):
        raise HTTPException(status_code=404, detail="Student not found")
    record = StudentAttendance(**payload.model_dump())
    db.add(record)
    try:
        db.commit()
        db.refresh(record)
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="Attendance already exists for this student and date")
    return record


@router.get("/students/", response_model=list[StudentAttendanceOut])
def list_student_attendance(student_id: int | None = None, db: Session = Depends(get_db)):
    query = select(StudentAttendance).order_by(StudentAttendance.attendance_date.desc())
    if student_id is not None:
        query = query.where(StudentAttendance.student_id == student_id)
    return db.scalars(query.limit(500)).all()


@router.post("/teachers/", response_model=TeacherAttendanceOut, status_code=status.HTTP_201_CREATED)
def teacher_check_in(payload: TeacherCheckIn, db: Session = Depends(get_db)):
    if not db.get(Teacher, payload.teacher_id):
        raise HTTPException(status_code=404, detail="Teacher not found")
    record = TeacherAttendance(
        teacher_id=payload.teacher_id,
        attendance_date=payload.attendance_date,
        status=payload.status,
        check_in=payload.check_in,
        notes=payload.notes,
    )
    db.add(record)
    try:
        db.commit()
        db.refresh(record)
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="Teacher attendance already exists for this date")
    return record


@router.post("/teachers/{attendance_id}/check-out", response_model=TeacherAttendanceOut)
def teacher_check_out(attendance_id: int, db: Session = Depends(get_db)):
    record = db.get(TeacherAttendance, attendance_id)
    if not record:
        raise HTTPException(status_code=404, detail="Teacher attendance record not found")
    if record.check_out is not None:
        raise HTTPException(status_code=409, detail="Teacher has already checked out")
    from datetime import datetime
    record.check_out = datetime.now()
    db.commit()
    db.refresh(record)
    return record


@router.get("/teachers/", response_model=list[TeacherAttendanceOut])
def list_teacher_attendance(teacher_id: int | None = None, db: Session = Depends(get_db)):
    query = select(TeacherAttendance).order_by(TeacherAttendance.attendance_date.desc())
    if teacher_id is not None:
        query = query.where(TeacherAttendance.teacher_id == teacher_id)
    return db.scalars(query.limit(500)).all()
