from datetime import datetime
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import SalaryRecord, Teacher
from ..schemas import SalaryCreate, SalaryOut, SalarySummary

router = APIRouter(prefix="/salaries", tags=["Teacher Salaries"])


def to_summary(record: SalaryRecord) -> SalarySummary:
    net = record.base_salary + record.allowances - record.deductions
    return SalarySummary(
        id=record.id,
        teacher_id=record.teacher_id,
        salary_month=record.salary_month,
        base_salary=record.base_salary,
        allowances=record.allowances,
        deductions=record.deductions,
        net_salary=net,
        status=record.status,
        paid_at=record.paid_at,
    )


@router.post("/", response_model=SalarySummary, status_code=status.HTTP_201_CREATED)
def create_salary(payload: SalaryCreate, db: Session = Depends(get_db)):
    if not db.get(Teacher, payload.teacher_id):
        raise HTTPException(status_code=404, detail="Teacher not found")
    record = SalaryRecord(**payload.model_dump())
    db.add(record)
    try:
        db.commit()
        db.refresh(record)
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="Salary record already exists for this teacher and month")
    return to_summary(record)


@router.get("/teacher/{teacher_id}", response_model=list[SalarySummary])
def teacher_salary_history(teacher_id: int, db: Session = Depends(get_db)):
    if not db.get(Teacher, teacher_id):
        raise HTTPException(status_code=404, detail="Teacher not found")
    records = db.scalars(
        select(SalaryRecord)
        .where(SalaryRecord.teacher_id == teacher_id)
        .order_by(SalaryRecord.salary_month.desc())
    ).all()
    return [to_summary(record) for record in records]


@router.post("/{salary_id}/pay", response_model=SalarySummary)
def mark_salary_paid(salary_id: int, db: Session = Depends(get_db)):
    record = db.get(SalaryRecord, salary_id)
    if not record:
        raise HTTPException(status_code=404, detail="Salary record not found")
    if record.status == "paid":
        raise HTTPException(status_code=409, detail="Salary is already marked as paid")
    record.status = "paid"
    record.paid_at = datetime.now()
    db.commit()
    db.refresh(record)
    return to_summary(record)


@router.get("/", response_model=list[SalarySummary])
def list_salaries(teacher_id: int | None = None, salary_month: str | None = None,
                  db: Session = Depends(get_db)):
    query = select(SalaryRecord).order_by(SalaryRecord.salary_month.desc())
    if teacher_id is not None:
        query = query.where(SalaryRecord.teacher_id == teacher_id)
    if salary_month is not None:
        import re
        if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", salary_month):
            raise HTTPException(status_code=400, detail="salary_month must use YYYY-MM format")
        query = query.where(SalaryRecord.salary_month == salary_month)
    return [to_summary(r) for r in db.scalars(query.limit(500)).all()]
