from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Teacher
from ..schemas import TeacherCreate, TeacherOut

router = APIRouter(prefix="/teachers", tags=["Teachers"])


@router.post("/", response_model=TeacherOut, status_code=status.HTTP_201_CREATED)
def create_teacher(payload: TeacherCreate, db: Session = Depends(get_db)):
    teacher = Teacher(**payload.model_dump())
    db.add(teacher)
    try:
        db.commit()
        db.refresh(teacher)
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="A teacher with this email already exists")
    return teacher


@router.get("/", response_model=list[TeacherOut])
def list_teachers(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    if skip < 0 or not 1 <= limit <= 200:
        raise HTTPException(status_code=400, detail="skip must be >= 0 and limit must be between 1 and 200")
    return db.scalars(select(Teacher).offset(skip).limit(limit)).all()


@router.get("/{teacher_id}", response_model=TeacherOut)
def get_teacher(teacher_id: int, db: Session = Depends(get_db)):
    teacher = db.get(Teacher, teacher_id)
    if not teacher:
        raise HTTPException(status_code=404, detail="Teacher not found")
    return teacher
