# Student Management System REST API

Beginner project using Python, FastAPI, SQLAlchemy, and MySQL.

## Features
- Student registration and listing
- Teacher registration and listing
- Student and teacher attendance
- Check-in/check-out and working-hour calculation
- Teacher salary records and payment tracking
- Interactive API docs at `/docs`

## 1. Create the MySQL database

Open MySQL Workbench or the MySQL command line and run:

```sql
CREATE DATABASE student_management
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;
```

Create a MySQL user with permission to use this database, or use your existing local development account.

## 2. Configure environment

Copy `.env.example` to `.env`, then set your MySQL credentials. Never commit `.env` to source control.

Example:
```env
DB_HOST=localhost
DB_PORT=3306
DB_NAME=student_management
DB_USER=root
DB_PASSWORD=your_actual_password
```

## 3. Install and run in IntelliJ IDEA terminal

Windows:
```powershell
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

macOS/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000/docs to try the endpoints. The tables are created automatically on first startup.

## Endpoints

- `POST /students/` — register a student
- `GET /students/` — list students
- `GET /students/{student_id}` — get a student
- `POST /teachers/` — register a teacher
- `GET /teachers/` — list teachers
- `GET /teachers/{teacher_id}` — get a teacher
- `POST /attendance/students/` — mark student attendance
- `GET /attendance/students/` — list student attendance
- `POST /attendance/teachers/` — mark teacher attendance and check in
- `POST /attendance/teachers/{attendance_id}/check-out` — check out a teacher
- `GET /attendance/teachers/` — list teacher attendance
- `POST /salaries/` — create a salary record
- `GET /salaries/teacher/{teacher_id}` — salary history for a teacher
- `POST /salaries/{salary_id}/pay` — mark salary as paid

## Important notes
- This is a learning starter project, not a production-ready school system.
- Add authentication and role-based authorization before deploying it.
- Validate your school's policies for attendance corrections, payroll, privacy, and record retention.
- The API prevents duplicate attendance entries for the same person and date at the application level; production systems should also enforce database uniqueness constraints and handle concurrent requests.
- Store real credentials only in `.env`; keep it private.
